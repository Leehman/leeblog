<template>
  <v-app>
    <v-navigation-drawer
      fixed
      :mini-variant="miniVariant"
      :clipped="clipped"
      v-model="drawer"
      app
    >
      <v-list>
        <v-list-tile
          value="true"
          v-for="(item, i) in items"
          :key="i"
        >
          <v-list-tile-action>
            <v-icon v-html="item.icon"></v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title v-text="item.title"></v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
      </v-list>
    </v-navigation-drawer>
    <v-toolbar fixed app :clipped-left="clipped">
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      <v-btn icon @click.stop="miniVariant = !miniVariant">
        <v-icon v-html="miniVariant ? 'chevron_right' : 'chevron_left'"></v-icon>
      </v-btn>
      <v-btn icon @click.stop="clipped = !clipped">
        <v-icon>web</v-icon>
      </v-btn>
      <v-btn icon @click.stop="fixed = !fixed">
        <v-icon>remove</v-icon>
      </v-btn>
      <v-toolbar-title v-text="title"></v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn icon @click.stop="rightDrawer = !rightDrawer">
        <v-icon>menu</v-icon>
      </v-btn>
    </v-toolbar>
    <v-content>
      <v-container fluid>
          <v-layout column align-center>
            <template>
                <v-card>
                <form>
                  <div>Blog Post:</div>
                  <br>
                  <v-text-field
                  label="Blog Post"
                  v-model="blogpost"

                  ></v-text-field>
                  <br>
                  <v-btn @click="submit">submit</v-btn>
                  <v-btn @click="clear">clear</v-btn>
                  <br>
                </form>
                </v-card>

            </template>
          </v-layout>
            <br>
          <v-layout column align-center>
            <template>
                <v-card>
                  <br>
                  <div>Blog Post List:</div>
                  <br>
                    <ul>
                      <li v-for="item in blogpostitems" >
                        {{ blogpost}} <v-btn @click="editupdate">Edit / Update</v-btn>
                      </li>
                    </ul>

                  <br>
              </v-card>
              </template>
          </v-layout>

      </v-container>
    </v-content>
    <v-navigation-drawer
      temporary
      :right="right"
      v-model="rightDrawer"
      fixed
    >
      <v-list>
        <v-list-tile @click.native="right = !right">
          <v-list-tile-action>
            <v-icon>compare_arrows</v-icon>
          </v-list-tile-action>
          <v-list-tile-title>Switch drawer (click me)</v-list-tile-title>
        </v-list-tile>
      </v-list>
    </v-navigation-drawer>
    <v-footer :fixed="fixed" app>
      <span>&copy; 2017</span>
    </v-footer>
  </v-app>
</template>

<script>
  export default {
    data () {
      return {
        clipped: false,
        drawer: true,
        fixed: false,
        items: [
          { icon: 'bubble_chart', title: 'Inspire' }
        ],
        miniVariant: false,
        right: true,
        rightDrawer: false,
        title: 'Blog - Lee',
        blogpost: '',
        blogpostitems: [{}],
        newpost: ''
      }
    }
  ,
  methods: {
    submit () {
      var text;
      //text = {{ blogpost}};
      if (text){
        this.blogpostitems.push({
          text: text

        })
        this.newpost = '';
      }
        },
    clear () {
        this.$refs.form.reset()

    },
    editupdate () {
      alert("hi");

    }
  }

  }
</script>
